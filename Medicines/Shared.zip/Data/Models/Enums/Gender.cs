﻿public enum Gender
{
    male = 0, female
}