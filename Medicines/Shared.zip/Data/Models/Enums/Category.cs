﻿namespace Medicines.Data.Models.Enums;

public enum Category
{
    analgesic = 0, antibiotic=1, antiseptic=2, sedative=3, vaccine=4
}