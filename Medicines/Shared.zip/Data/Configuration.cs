﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"";
        public static string connectionFootballersH => "Server=localhost\\SQLExpress;Database=Medicine;Trusted_Connection=True;Integrated Security=True";
        public static string connectionFootballersW => "Server=localhost;Database=Medicine;User id=sa;password=c0m@n$!@#$";
    }
}
